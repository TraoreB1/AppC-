# Sicilylines_Mission2

Application créer pour mettre en pratique nos premières connaissance de sur C#. 
Elle permet de modifier le nom du secteur, de supprimer un secteur, de supprimer une liaison de deux ports, de modifier la durée de deux ports et d'ajouter une nouvelle liaison. 


![frontapp](https://user-images.githubusercontent.com/108392457/220948118-bdaacdb9-1334-41c6-869f-08c9223518ce.png)


![capp](https://user-images.githubusercontent.com/108392457/220948173-c6b50cf7-7cf5-4523-adcf-1ee4d98db25c.png)
